import { Routes } from '@angular/router';
import { MyCoursesComponent } from './features/courses/my-courses/my-courses.component';
import { LoginComponent } from './features/auth/login/login.component';
import { RegisterComponent } from './features/auth/register/register.component';
import { VerifyEmailComponent } from './features/auth/verify-email/verify-email.component';
import { CourseListComponent } from './features/courses/courses-list/courses-list.component';
import { CourseDetailComponent } from './features/courses/course-detail/course-detail.component';
import { CourseLessonComponent } from './features/courses/course-lesson/course-lesson.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';
import { DashboardComponent } from './features/user/dashboard/dashboard.component';
import { ProfileComponent } from './features/user/profile/profile.component';
import { AdminDashboardComponent } from './features/admin/admin-dashboard/admin-dashboard.component';
import { CoursesAdminComponent } from './features/admin/courses-admin/courses-admin.component';
import { CourseFormComponent } from './features/admin/course-form/course-form.component';

export const routes: Routes = [
  { path: '', redirectTo: 'register', pathMatch: 'full' },
  
  // Auth Routes
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'verify-email', component: VerifyEmailComponent },
  
  // User Routes
  { path: 'dashboard', component: DashboardComponent },
  { path: 'profile', component: ProfileComponent },
  
  // Course Routes
  { path: 'courses', component: CourseListComponent },
  { path: 'courses/:slug', component: CourseDetailComponent },
  { path: 'my-courses', component: MyCoursesComponent },
  { path: 'my-courses/:courseId/learn', component: CourseLessonComponent }, // 🔴 FIXED: Learning page
  
  // Admin Routes
  {
    path: 'admin',
    children: [
      {
        path: '',
        component: AdminDashboardComponent,
      },
      {
        path: 'courses',
        component: CoursesAdminComponent,
      },
      {
        path: 'courses/new',
        component: CourseFormComponent,
      },
      {
        path: 'courses/:id/edit',
        component: CourseFormComponent,
      },
    ],
  },
];
