import { HttpInterceptorFn } from '@angular/common/http';

export const auth4Interceptor: HttpInterceptorFn = (req, next) => {
  return next(req);
};
