import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { EnrollmentService } from '../../../core/services/enrollment.service';
import { AuthService } from '../../../core/auth.service';

interface CourseDetail {
  _id: string;
  title: string;
  slug: string;
  description: string;
  price: number;
  thumbnail: string;
  videoUrl: string;
  level: string;
  category: string;
  tagLine: string;
  lessonsCount: number;
  totalDurationMinutes: number;
  lastUpdated: string;
}

@Component({
  selector: 'app-course-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './course-detail.component.html',
  styleUrls: ['./course-detail.component.css'],
})
export class CourseDetailComponent implements OnInit {
  course: CourseDetail | null = null;
  loading = false;
  error: string | null = null;
  enrolling = false;
  enrollSuccess: string | null = null;

  private apiUrl = 'http://localhost:5000/api/courses';

  constructor(
    public route: ActivatedRoute,
    public http: HttpClient,
    public enrollmentService: EnrollmentService,
    public authService: AuthService,
    public router: Router
  ) {}

  ngOnInit(): void {
  // 🔴 Subscribe to route params for every change
  this.route.paramMap.subscribe((params) => {
    const slug = params.get('slug');
    if (!slug) {
      this.error = 'Invalid course URL.';
      return;
    }
    this.fetchCourse(slug);
  });
}


  fetchCourse(slug: string) {
    this.loading = true;
    this.error = null;

    this.http
      .get<{ success: boolean; course: CourseDetail }>(
        `${this.apiUrl}/${slug}`
      )
      .subscribe({
        next: (res) => {
          this.course = res.course;
          this.loading = false;
        },
        error: (err) => {
          console.error('Course load error', err);
          this.error = 'Failed to load course.';
          this.loading = false;
        },
      });
  }

  // 🔴 ADD THIS METHOD (called by error banner retry button)
  loadCourse(slug: string) {
    if (!slug || slug.trim() === '') {
      this.error = 'Invalid course URL.';
      return;
    }
    this.fetchCourse(slug);
  }

  goBack() {
    this.router.navigate(['/courses']);
  }

  enroll() {
    if (!this.course || this.enrolling) return;

    if (!this.authService.isLoggedIn()) {
      this.router.navigate(['/login'], {
        queryParams: { redirectTo: `/courses/${this.course.slug}` },
      });
      return;
    }

    this.enrolling = true;
    this.enrollSuccess = null;
    this.error = null;

    this.enrollmentService.enrollCourse(this.course._id).subscribe({
      next: () => {
        this.enrolling = false;
        this.enrollSuccess = 'Enrolled successfully! Redirecting to My Courses...';

        setTimeout(() => {
          this.router.navigate(['/my-courses']);
        }, 1000);
      },
      error: (err: { error: { message: string } }) => {
        console.error('Enroll error', err);
        this.enrolling = false;
        this.error =
          err?.error?.message || 'Failed to enroll. Please try again.';
      },
    });
  }
}
