import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { EnrollmentService } from '../../../core/services/enrollment.service';

interface CourseDetail {
  _id: string;
  title: string;
  description: string;
  videoUrl: string;
  lessonsCount: number;
  totalDurationMinutes: number;
}

@Component({
  selector: 'app-course-lesson',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './course-lesson.component.html',
  styleUrls: ['./course-lesson.component.css'],
})
export class CourseLessonComponent implements OnInit {
  courseId: string = '';
  course: CourseDetail | null = null;
  loading = false;
  error: string | null = null;
  currentLesson = 0;

  private apiUrl = 'http://localhost:5000/api/courses';

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    public router: Router,
    private enrollmentService: EnrollmentService
  ) {}

  ngOnInit(): void {
    this.courseId = this.route.snapshot.paramMap.get('courseId') || '';
    if (!this.courseId) {
      this.error = 'Invalid course ID';
      return;
    }
    this.loadCourse();
  }

  loadCourse() {
    this.loading = true;
    this.error = null;

    this.http
      .get<{ success: boolean; course: CourseDetail }>(
        `${this.apiUrl}/${this.courseId}`
      )
      .subscribe({
        next: (res) => {
          this.course = res.course;
          this.loading = false;
        },
        error: (err) => {
          console.error('Course load error', err);
          this.error = 'Failed to load course';
          this.loading = false;
        },
      });
  }

  markComplete() {
    const lessonKey = `${this.currentLesson}-${this.currentLesson + 1}`;
    
    this.enrollmentService
      .updateProgress(this.courseId, lessonKey)
      .subscribe({
        next: () => {
          alert('Lesson marked complete!');
          if (this.currentLesson < (this.course?.lessonsCount || 1) - 1) {
            this.nextLesson();
          }
        },
        error: (err) => {
          console.error('Progress update error', err);
          alert('Failed to mark lesson complete');
        },
      });
  }

  nextLesson() {
    if (this.currentLesson < (this.course?.lessonsCount || 1) - 1) {
      this.currentLesson++;
    }
  }

  previousLesson() {
    if (this.currentLesson > 0) {
      this.currentLesson--;
    }
  }

  goBack() {
    this.router.navigate(['/my-courses']);
  }
}
