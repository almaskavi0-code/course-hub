import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { EnrollmentService, MyCourse } from '../../../core/services/enrollment.service';

@Component({
  selector: 'app-my-courses',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './my-courses.component.html',
  styleUrls: ['./my-courses.component.css'],
})
export class MyCoursesComponent implements OnInit {
  courses: MyCourse[] = [];
  loading = false;
  error: string | null = null;

  constructor(
    private enrollmentService: EnrollmentService,
    public router: Router  // 🔴 CHANGED: private → public
  ) {}

  ngOnInit(): void {
    this.loadCourses();
  }

  loadCourses() {
    this.loading = true;
    this.error = null;

    this.enrollmentService.getMyCourses().subscribe({
      next: (res) => {
        this.courses = res.courses || [];
        this.loading = false;
      },
      error: (err) => {
        console.error('My courses error', err);
        this.error =
          err?.error?.message || 'Failed to load your courses. Please try again.';
        this.loading = false;
      },
    });
  }

  openCourse(course: MyCourse) {
    this.router.navigate(['/courses', course.slug]);
  }
}
