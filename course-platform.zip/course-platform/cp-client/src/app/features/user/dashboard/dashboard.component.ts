import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../../core/auth.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  user: any = null;
  loading = true;
  isAdmin = false; // 🔹 Add this
  userName = ''; // 🔹 Add this

  constructor(
    private http: HttpClient,
    private auth: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const token = this.auth.getToken();

    if (!token) {
      this.router.navigate(['/login']);
      return;
    }

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });

    this.http
      .get('http://localhost:5000/api/user/me', { headers })
      .subscribe({
        next: (res: any) => {
          this.loading = false;
          this.user = res.user;
          this.userName = res.user?.name || 'User';
          this.isAdmin = res.user?.role === 'admin'; // 🔹 Check if admin

          console.log('User role:', res.user?.role, 'Is admin?', this.isAdmin);
        },
        error: (err) => {
          this.loading = false;
          console.error('Error fetching user:', err);
          this.router.navigate(['/login']);
        },
      });
  }

  logout() {
    localStorage.removeItem('cp_token');
    localStorage.removeItem('cp_user');
    this.router.navigate(['/login']);
  }
}
