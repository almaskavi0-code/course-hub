import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AdminService } from '../../../core/admin.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css'],
})
export class AdminDashboardComponent implements OnInit {
  private adminService = inject(AdminService);

  totalCourses = 0;
  totalUsers = 0;
  revenueEstimate = 0;
  loading = false;

  ngOnInit() {
    this.loadStats();
  }

  loadStats() {
    this.loading = true;
    this.adminService.getAllCourses().subscribe({
      next: (res) => {
        this.totalCourses = res.courses?.length || 0;
        // Later: add user + revenue stats from more API endpoints
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      },
    });
  }
}
