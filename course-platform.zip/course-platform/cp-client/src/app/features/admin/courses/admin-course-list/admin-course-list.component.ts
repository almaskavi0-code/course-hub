import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {
  AdminCourse,
  AdminCourseService,
} from '../../../../core/services/admin-course.service';

@Component({
  selector: 'app-admin-course-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './admin-course-list.component.html',
  styleUrls: ['./admin-course-list.component.css'],
})
export class AdminCourseListComponent implements OnInit {
  courses: AdminCourse[] = [];
  loading = false;
  error = '';
  search = '';

  constructor(private adminCourseService: AdminCourseService) {}

  ngOnInit(): void {
    this.loadCourses();
  }

  loadCourses() {
    this.loading = true;
    this.error = '';

    this.adminCourseService.getCourses({ search: this.search }).subscribe({
      next: (res) => {
        this.courses = res.courses;
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to load courses';
        this.loading = false;
      },
    });
  }

  onSearchChange() {
    this.loadCourses();
  }

  togglePublish(course: AdminCourse) {
    this.adminCourseService.togglePublish(course._id).subscribe({
      next: (res: any) => {
        const idx = this.courses.findIndex((c) => c._id === course._id);
        if (idx > -1) {
          this.courses[idx] = res.course;
        }
      },
      error: () => {
        alert('Failed to update publish status');
      },
    });
  }

  deleteCourse(id: string, title: string) {
    if (
      confirm(
        `Are you sure you want to delete "${title}"? This action cannot be undone.`
      )
    ) {
      this.adminCourseService.deleteCourse(id).subscribe({
        next: () => {
          this.courses = this.courses.filter((c) => c._id !== id);
          alert('Course deleted successfully!');
        },
        error: () => {
          alert('Failed to delete course');
        },
      });
    }
  }
}
