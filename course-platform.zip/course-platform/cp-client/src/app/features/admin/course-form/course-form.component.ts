import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminService } from '../../../core/admin.service';
import { CoursesService, Course } from '../../../core/courses.service';

@Component({
  selector: 'app-course-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './course-form.component.html',
  styleUrls: ['./course-form.component.css'],
})
export class CourseFormComponent implements OnInit {
  private fb = inject(FormBuilder);
  private route = inject(ActivatedRoute);
router = inject(Router); // 'private' hata do
  private adminService = inject(AdminService);
  private coursesService = inject(CoursesService);

  form!: FormGroup;
  loading = false;
  submitting = false;
  error = '';
  isEditMode = false;
  courseId = '';

  ngOnInit() {
    this.initForm();
    
    // Check if edit mode
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEditMode = true;
      this.courseId = id;
      this.loadCourse(id);
    }
  }

  initForm() {
    this.form = this.fb.group({
      title: ['', [Validators.required, Validators.minLength(5)]],
      slug: ['', [Validators.required]],
      description: ['', [Validators.required, Validators.minLength(20)]],
      price: [0, [Validators.required, Validators.min(0)]],
      thumbnail: ['', [Validators.required]],
      videoUrl: [''],
      level: ['intermediate', Validators.required],
      lessonsCount: [1, [Validators.required, Validators.min(1)]],
      isPublished: [true],
    });
  }

  loadCourse(id: string) {
    this.loading = true;
    this.adminService.getAllCourses().subscribe({
      next: (res) => {
        const course = res.courses?.find((c) => c._id === id);
        if (course) {
          this.form.patchValue(course);
        }
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to load course';
        this.loading = false;
      },
    });
  }

  onSubmit() {
    if (!this.form.valid) {
      this.error = 'Please fill all required fields';
      return;
    }

    this.submitting = true;
    this.error = '';

    const data = this.form.value;

    const request = this.isEditMode
      ? this.adminService.updateCourse(this.courseId, data)
      : this.adminService.createCourse(data);

    request.subscribe({
      next: (res) => {
        this.submitting = false;
        alert(this.isEditMode ? 'Course updated!' : 'Course created!');
        this.router.navigate(['/admin/courses']);
      },
      error: (err) => {
        this.submitting = false;
        this.error = err.error?.message || 'Failed to save course';
      },
    });
  }

  // Auto-generate slug from title
  onTitleChange() {
    const title = this.form.get('title')?.value || '';
    const slug = title
      .toLowerCase()
      .trim()
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-');
    
    this.form.patchValue({ slug }, { emitEvent: false });
  }
}
