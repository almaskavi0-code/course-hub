import { Injectable } from '@angular/core';
import {
  CanActivateFn,
  Router,
} from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AuthGuardService {
  constructor(private router: Router) {}

  canActivate(): boolean {
    const token = localStorage.getItem('cp_token');
    if (!token) {
      this.router.navigate(['/login']);
      return false;
    }
    return true;
  }
}

// function-style guard for Angular 15+
export const authGuard: CanActivateFn = (route, state) => {
  const guard = new AuthGuardService((window as any).injector.get(Router));
  return guard.canActivate();
};
