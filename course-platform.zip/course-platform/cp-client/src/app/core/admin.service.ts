import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Course } from './courses.service';

@Injectable({ providedIn: 'root' })
export class AdminService {
  private http = inject(HttpClient);
  private baseUrl = 'http://localhost:5000/api/admin';

  // Courses
  getAllCourses(): Observable<{ success: boolean; courses: Course[] }> {
    const token = localStorage.getItem('cp_token') || '';
    return this.http.get<{ success: boolean; courses: Course[] }>(
      `${this.baseUrl}/courses`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
  }

  createCourse(data: Partial<Course>): Observable<{ success: boolean; course: Course }> {
    const token = localStorage.getItem('cp_token') || '';
    return this.http.post<{ success: boolean; course: Course }>(
      `${this.baseUrl}/courses`,
      data,
      { headers: { Authorization: `Bearer ${token}` } }
    );
  }

  updateCourse(
    id: string,
    data: Partial<Course>
  ): Observable<{ success: boolean; course: Course }> {
    const token = localStorage.getItem('cp_token') || '';
    return this.http.put<{ success: boolean; course: Course }>(
      `${this.baseUrl}/courses/${id}`,
      data,
      { headers: { Authorization: `Bearer ${token}` } }
    );
  }

  deleteCourse(id: string): Observable<{ success: boolean }> {
    const token = localStorage.getItem('cp_token') || '';
    return this.http.delete<{ success: boolean }>(
      `${this.baseUrl}/courses/${id}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
  }
}
