import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface AdminCourse {
  _id: string;
  title: string;
  slug: string;
  price: number;
  level: string;
  category: string;
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
}

@Injectable({
  providedIn: 'root',
})
export class AdminCourseService {
  private baseUrl = 'http://localhost:5000/api/admin/courses';

  constructor(private http: HttpClient) {}

  // 🔧 Helper method to get headers with token
  private getHeaders(): HttpHeaders {
  const token = localStorage.getItem('cp_token'); // ✅ FIXED: 'cp_token' not 'token'
  let headers = new HttpHeaders();
  
  if (token) {
    headers = headers.set('Authorization', `Bearer ${token}`);
  }
  
  return headers;
}


  getCourses(filters?: {
    search?: string;
    category?: string;
    level?: string;
    isPublished?: boolean;
  }): Observable<{ success: boolean; courses: AdminCourse[] }> {
    let params = new HttpParams();

    if (filters?.search) params = params.set('search', filters.search);
    if (filters?.category) params = params.set('category', filters.category);
    if (filters?.level) params = params.set('level', filters.level);
    if (typeof filters?.isPublished === 'boolean') {
      params = params.set('isPublished', String(filters.isPublished));
    }

    return this.http.get<{ success: boolean; courses: AdminCourse[] }>(
      this.baseUrl,
      { params, headers: this.getHeaders() } // ✅ Token bhej raha hai
    );
  }

  createCourse(data: any) {
    return this.http.post<{ success: boolean; course: AdminCourse }>(
      this.baseUrl,
      data,
      { headers: this.getHeaders() } // ✅ Token
    );
  }
getCourse(id: string) {
  return this.http.get<{ success: boolean; course: any }>(
    `${this.baseUrl}/${id}`,
    { headers: this.getHeaders() }
  );
}

  updateCourse(id: string, data: any) {
    return this.http.put<{ success: boolean; course: AdminCourse }>(
      `${this.baseUrl}/${id}`,
      data,
      { headers: this.getHeaders() } // ✅ Token
    );
  }

  deleteCourse(id: string) {
    return this.http.delete<{ success: boolean }>(
      `${this.baseUrl}/${id}`,
      { headers: this.getHeaders() } // ✅ Token
    );
  }

  togglePublish(id: string) {
    return this.http.patch<{ success: boolean; course: AdminCourse }>(
      `${this.baseUrl}/${id}/publish`,
      {},
      { headers: this.getHeaders() } // ✅ Token
    );
  }
}
