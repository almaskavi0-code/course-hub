import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';

interface RegisterPayload {
  name: string;
  email: string;
  password: string;
}

interface LoginPayload {
  email: string;
  password: string;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = 'http://localhost:5000/api/auth';

  constructor(private http: HttpClient, private router: Router) {}

  private authHeaders() {
  const token = this.getToken();
  return new HttpHeaders({
    Authorization: `Bearer ${token}`,
  });
}


  // ✅ FIXED: Register with token save
  register(payload: RegisterPayload): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, payload).pipe(
      tap((res: any) => {
        if (res.token) {
          localStorage.setItem('cp_token', res.token);
          this.router.navigate(['/dashboard']);
        }
      })
    );
  }

  // ✅ FIXED: Login with token save
  login(payload: LoginPayload): Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, payload).pipe(
      tap((res: any) => {
        if (res.token) {
          localStorage.setItem('cp_token', res.token); // ✅ Save token!
          this.router.navigate(['/dashboard']);
        }
      })
    );
  }

  // ✅ Verify email
  verifyEmail(token: string) {
    return this.http.get(`${this.apiUrl}/verify-email`, {
      params: { token },
    });
  }

  // ✅ Get token
  getToken() {
    return localStorage.getItem('cp_token');
  }

  // ✅ Check if logged in
  isLoggedIn(): boolean {
    const token = localStorage.getItem('cp_token');
    return !!token;
  }

  // ✅ Update profile with proper headers
  updateProfile(data: { name?: string; email?: string }): Observable<any> {
    const headers = this.authHeaders();

    // const headers = new HttpHeaders({
    //   Authorization: `Bearer ${token}`,
    // });
    return this.http.put(
      `http://localhost:5000/api/user/update-profile`,
      data,
      { headers }
    );
  }

  // ✅ Change password with proper headers
  changePassword(data: {
    currentPassword: string;
    newPassword: string;
  }): Observable<any> {
    const token = localStorage.getItem('cp_token');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.put(
      `http://localhost:5000/api/user/change-password`,
      data,
      { headers }
    );
  }

  // ✅ Logout
  logout() {
    localStorage.removeItem('cp_token');
    this.router.navigate(['/login']);
  }
}
