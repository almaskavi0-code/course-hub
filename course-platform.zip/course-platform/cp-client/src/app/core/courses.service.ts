// src/app/core/courses.service.ts
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Course {
  updatedAt: string | undefined;
  _id: string;
  title: string;
  slug: string;
  description: string;
  price: number;
  thumbnail: string;
  level: string;
  lessonsCount: number;

  // new
  lastUpdated?: string;
  progressPercent?: number;
  hoursLearned?: number;
  videoUrl?: string; 

  
  // existing extras
  progress?: number;
  lastActivity?: Date;

  
}

@Injectable({
  providedIn: 'root',
})
export class CoursesService {
  private http = inject(HttpClient);
  private baseUrl = 'http://localhost:5000/api';

  // Public catalog
  getCourses(): Observable<{ success: boolean; courses: Course[] }> {
    return this.http.get<{ success: boolean; courses: Course[] }>(
      `${this.baseUrl}/courses`
    );
  }
getCourseBySlug(slug: string) {
  return this.http.get<{ success: boolean; course: Course }>(
    `${this.baseUrl}/courses/${slug}`
  );
}


  // My Courses (enrolled)
  getMyCourses(): Observable<{ success: boolean; courses: Course[] }> {
    const token = localStorage.getItem('cp_token') || '';
    return this.http.get<{ success: boolean; courses: Course[] }>(
      `${this.baseUrl}/user/my-courses`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
  }

  // Enroll in a course
  enroll(courseId: string): Observable<{ success: boolean; message: string }> {
    const token = localStorage.getItem('cp_token') || '';
    return this.http.post<{ success: boolean; message: string }>(
      `${this.baseUrl}/courses/${courseId}/enroll`,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
  }
}
