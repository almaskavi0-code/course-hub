const express = require("express");
const router = express.Router();
const User = require("../models/User");
const Course = require("../models/Course");
const Enrollment = require("../models/Enrollment");
const { protect, adminOnly } = require("../middleware/auth");

// GET /api/admin/dashboard/stats
router.get("/stats", protect, adminOnly, async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalCourses = await Course.countDocuments();
    const totalEnrollments = await Enrollment.countDocuments();
    
    // This month
    const startOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const newUsersThisMonth = await User.countDocuments({
      createdAt: { $gte: startOfMonth }
    });
    
    const newEnrollmentsThisMonth = await Enrollment.countDocuments({
      createdAt: { $gte: startOfMonth }
    });

    // Revenue calculation (from Enrollment with price)
    const enrollmentsWithPrice = await Enrollment.aggregate([
      {
        $lookup: {
          from: "courses",
          localField: "course",
          foreignField: "_id",
          as: "courseData"
        }
      },
      {
        $unwind: "$courseData"
      },
      {
        $group: {
          _id: null,
          totalRevenue: { $sum: "$courseData.price" }
        }
      }
    ]);

    const totalRevenue = enrollmentsWithPrice[0]?.totalRevenue || 0;

    res.json({
      success: true,
      stats: {
        totalUsers,
        totalCourses,
        totalEnrollments,
        newUsersThisMonth,
        newEnrollmentsThisMonth,
        totalRevenue,
        avgCoursePrice: totalCourses > 0 ? (totalRevenue / totalEnrollments) : 0
      }
    });
  } catch (err) {
    console.error("Dashboard stats error:", err);
    res.status(500).json({ success: false, message: "Error fetching stats" });
  }
});

// GET /api/admin/dashboard/charts/revenue
router.get("/charts/revenue", protect, adminOnly, async (req, res) => {
  try {
    const last30Days = new Date();
    last30Days.setDate(last30Days.getDate() - 30);

    const revenueData = await Enrollment.aggregate([
      {
        $match: { createdAt: { $gte: last30Days } }
      },
      {
        $lookup: {
          from: "courses",
          localField: "course",
          foreignField: "_id",
          as: "courseData"
        }
      },
      {
        $unwind: "$courseData"
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m-%d", date: "$createdAt" }
          },
          revenue: { $sum: "$courseData.price" }
        }
      },
      {
        $sort: { _id: 1 }
      }
    ]);

    res.json({
      success: true,
      chartData: revenueData.map(item => ({
        date: item._id,
        revenue: item.revenue
      }))
    });
  } catch (err) {
    res.status(500).json({ success: false, message: "Error fetching revenue data" });
  }
});

// GET /api/admin/dashboard/charts/users
router.get("/charts/users", protect, adminOnly, async (req, res) => {
  try {
    const last30Days = new Date();
    last30Days.setDate(last30Days.getDate() - 30);

    const userData = await User.aggregate([
      {
        $match: { createdAt: { $gte: last30Days } }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m-%d", date: "$createdAt" }
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { _id: 1 }
      }
    ]);

    res.json({
      success: true,
      chartData: userData.map(item => ({
        date: item._id,
        users: item.count
      }))
    });
  } catch (err) {
    res.status(500).json({ success: false, message: "Error fetching user data" });
  }
});
// GET /api/admin/dashboard/charts/enrollments
router.get("/charts/enrollments", protect, adminOnly, async (req, res) => {
  try {
    const enrollmentByCourse = await Enrollment.aggregate([
      {
        $lookup: {
          from: "courses",
          localField: "course",
          foreignField: "_id",
          as: "courseData"
        }
      },
      { $unwind: "$courseData" },
      {
        $group: {
          _id: "$courseData.title",
          count: { $sum: 1 }
        }
      },
      { $sort: { count: -1 } },
      { $limit: 5 }
    ]);

    console.log("ENROLLMENTS AGG RESULT =>", enrollmentByCourse);

    res.json({
      success: true,
      chartData: enrollmentByCourse.map(item => ({
        course: item._id,
        enrollments: item.count
      }))
    });
  } catch (err) {
    console.error("Enrollments chart error:", err); // IMPORTANT
    res.status(500).json({ success: false, message: "Error fetching enrollment data" });
  }
});


module.exports = router;
