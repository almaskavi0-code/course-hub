// cp-server/routes/course.js
const express = require("express");
const Course = require("../models/Course");
const { protect } = require("../middleware/auth");

const router = express.Router();

// GET /api/courses  → public course list
router.get("/", async (req, res) => {
  try {
    const courses = await Course.find({ isPublished: true })
      .sort({ createdAt: -1 })
      .select("title slug description price thumbnail level lessonsCount");
    res.json({ success: true, courses });
  } catch (err) {
    console.error("Get courses error:", err.message);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// GET /api/courses/:slug → single course detail
router.get("/:slug", async (req, res) => {
  try {
    const course = await Course.findOne({
      slug: req.params.slug.toLowerCase(),
      isPublished: true,
    });

    if (!course) {
      return res
        .status(404)
        .json({ success: false, message: "Course not found" });
    }

    res.json({ success: true, course });
  } catch (err) {
    console.error("Get course detail error:", err.message);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// POST /api/courses/:id/enroll → requires login
router.post("/:id/enroll", protect, async (req, res) => {
  try {
    const courseId = req.params.id;

    // User model import karo
    const User = require("../models/User");
    const user = await User.findById(req.user._id);

    if (!user) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    // Ensure field exists
    if (!Array.isArray(user.enrolledCourses)) {
      user.enrolledCourses = [];
    }

    // Already enrolled?
    if (user.enrolledCourses.includes(courseId)) {
      return res.json({
        success: true,
        alreadyEnrolled: true,
        message: "Already enrolled in this course",
      });
    }

    user.enrolledCourses.push(courseId);
    await user.save();

    res.json({
      success: true,
      message: "Enrolled successfully in the course",
    });
  } catch (err) {
    console.error("Enroll error:", err.message);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

module.exports = router;
