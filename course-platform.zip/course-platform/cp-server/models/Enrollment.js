const mongoose = require("mongoose");

const enrollmentSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    course: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Course",
      required: true,
    },

    // lessonsCompleted ka count / ids
    completedLessons: [
      {
        type: String, // e.g. `${moduleIndex}-${lessonIndex}` ya lessonId
      },
    ],

    progressPercent: {
      type: Number,
      default: 0, // 0–100
    },
    hoursLearned: {
      type: Number,
      default: 0,
    },
    status: {
      type: String,
      enum: ["in-progress", "completed"],
      default: "in-progress",
    },
  },
  { timestamps: true }
);

// 1 user per course only once
enrollmentSchema.index({ user: 1, course: 1 }, { unique: true });

module.exports = mongoose.model("Enrollment", enrollmentSchema);
