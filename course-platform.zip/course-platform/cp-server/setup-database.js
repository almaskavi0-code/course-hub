import mongoose from 'mongoose';
import dotenv from 'dotenv';

dotenv.config();

const setupDatabase = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ Connected to MongoDB');

    const db = mongoose.connection;

    // 1. Users Collection
    await db.collection('users').insertOne({
      name: 'Hanzla Mansuri',
      email: 'hanzla@almaskavi.com',
      password: 'hashedPassword123', // In real, use bcrypt
      role: 'student',
      enrolledCourses: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    console.log('✅ Users collection created');

    // 2. Courses Collection
    const courseId = new mongoose.Types.ObjectId();
    await db.collection('courses').insertOne({
      _id: courseId,
      title: 'Complete Web Development 2024',
      description: 'Learn HTML, CSS, JavaScript, React, Node.js',
      instructor: 'Hanzla Mansuri',
      category: 'web-development',
      thumbnail: 'https://via.placeholder.com/300x200',
      duration: 40, // hours
      level: 'beginner',
      price: 0,
      rating: 4.8,
      enrollments: 1,
      modules: [
        {
          _id: new mongoose.Types.ObjectId(),
          title: 'Module 1: HTML Basics',
          lessons: [
            {
              _id: new mongoose.Types.ObjectId(),
              title: 'Lesson 1: HTML Structure',
              videoUrl: 'https://youtube.com/...',
              duration: 15,
            },
          ],
        },
      ],
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    console.log('✅ Courses collection created');

    // 3. Enrollments Collection
    const userId = new mongoose.Types.ObjectId();
    await db.collection('enrollments').insertOne({
      userId: userId,
      courseId: courseId,
      enrollmentDate: new Date(),
      progress: 0,
      lastAccessedAt: new Date(),
      completedModules: 0,
      totalModules: 8,
      status: 'in-progress',
      createdAt: new Date(),
    });
    console.log('✅ Enrollments collection created');

    // 4. Lessons Collection
    await db.collection('lessons').insertOne({
      courseId: courseId,
      moduleId: new mongoose.Types.ObjectId(),
      title: 'Lesson 1: HTML Structure',
      videoUrl: 'https://youtube.com/...',
      description: 'Learn HTML basics and structure',
      duration: 15,
      resources: [],
      createdAt: new Date(),
    });
    console.log('✅ Lessons collection created');

    // 5. Reviews Collection
    await db.collection('reviews').insertOne({
      courseId: courseId,
      userId: userId,
      rating: 5,
      comment: 'Excellent course for beginners!',
      createdAt: new Date(),
    });
    console.log('✅ Reviews collection created');

    console.log(`
    ✅ Database Setup Complete!
    
    📊 Collections Created:
       - users
       - courses
       - enrollments
       - lessons
       - reviews
    
    🎯 Ready to Use!
    `);

    await mongoose.disconnect();
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
};

setupDatabase();
